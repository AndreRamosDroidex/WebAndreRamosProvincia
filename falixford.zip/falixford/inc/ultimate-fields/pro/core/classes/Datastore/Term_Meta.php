<?php
namespace Ultimate_Fields\Pro\Datastore;

use Ultimate_Fields\Datastore;

/**
 * Connects the taxonomy location with the term meta API.
 *
 * @since 3.0
 */
class Term_Meta extends Datastore {
	protected $term_id = null;

    /**
	 * Retrieve a single value from the database.
	 *
	 * @since 2.0
	 *
	 * @param string $key The key of the value
	 * @return mixed An empty string if the value is not available or the value itself
	 */
	function get_value_from_db( $key ) {
		if( ! metadata_exists( 'term', $this->term_id, $key ) ) {
			return null;
		}

		return get_term_meta( $this->term_id, $key, true );
	}

	/**
	 * Saves values in the dabase. Might as well update existing ones
	 *
	 * @since 2.0
	 *
	 * @param string $key The key which the value is saved with
	 * @param mixed $value The value to be saved
	 */
	function save_value_in_db( $key, $value ) {
		return update_term_meta( $this->term_id, $key, $value );
	}

	/**
	 * Deletes values based on their key, no matter if they are multiple or not
	 *
	 * @since 2.0
	 *
	 * @param string $key The key of the setting
	 */
	function delete_value_from_db( $key ) {
		return delete_term_meta( $this->term_id, $key, true );
	}

	/**
	 * Commits the changes
	 */
	public function commit() {
		# Delete values
		foreach( $this->deleted as $key => $value ) {
			$this->delete_value_from_db( $key );
		}

		# Add/update the other ones
		foreach( $this->values as $key => $value ) {
			$this->save_value_in_db( $key, $value );
		}
	}

	/**
	 * Sets the term ID to work with.
	 *
	 * @since 3.0
	 *
	 * @param int $id The ID of the term.
	 */
	public function set_id( $id ) {
		$this->term_id = $id;
	}

	/**
	 * Returns the ID of the term the datastore gets meta for.
	 *
	 * @since 3.0
	 * @return int
	 */
	public function get_id() {
		return $this->term_id;
	}

	/**
	 * When used within the customizer, this will set temporary values to all overwritten fieds.
	 *
	 * @since 3.0
	 */
	public function set_temporary_values() {
		add_filter( "get_term_metadata", array( $this, 'overwrite_value' ), 10, 4 );
	}

	/**
	 * Overwrites a value when term meta is being retrieved.
	 * Used when values are changed in the customizer but should not be saved yet.
	 *
	 * @since 3.0
	 *
	 * @param  mixed  $value     The value that would be normally returned.
	 * @param  int    $object_id The ID othe object whose value is being retrieved.
	 * @param  string $meta_key  The key of the needed meta value.
	 * @param  bool   $single    Indiates if a single value is needed, having that key.
	 * @return mixed
	 */
	public function overwrite_value( $value, $object_id, $meta_key, $single ) {
		if( $this->term_id == $object_id ) {
			if( isset( $this->values[ $meta_key ] ) ) {
				return $this->values[ $meta_key ];
			}
		}

		return $value;
	}

	/**
	 * Returns the options and keywords for the data API.
	 *
	 * @since 3.0
	 *
	 * @return mixed[]
	 */
	public static function get_data_api_options() {
		$options = array();

		# On term pages, this will select the current term
		$options[] = array(
			'type'    => 'term_meta',
			'keyword' => 'term',
			'item'    => false
		);

		# This one will work when a specific term is requested
		$options[] = array(
			'type'    => 'term_meta',
			'keyword' => 'term',
			'item'    => true
		);

		foreach( get_taxonomies() as $slug ) {
			# On term pages, this will select the current term
			$options[] = array(
				'type'    => 'term_meta',
				'keyword' => $slug,
				'item'    => false
			);

			# This one will work when a specific term is requested
			$options[] = array(
				'type'    => 'term_meta',
				'keyword' => $slug,
				'item'    => true
			);
		}

		return $options;
	}

	/**
	 * Loads the current term for the no-item combination.
	 *
	 * @since 3.0
	 *
	 * @return int
	 */
	public static function load_anonymous_item() {
		return is_category() || is_tag() || is_tax()
			? get_queried_object()->term_id
			: false;
	}
}
