<?php
namespace Ultimate_Fields\Pro\Helper;

use Ultimate_Fields\Helper\Group_Values;

class Layout_Group_Values extends Group_Values {

}
