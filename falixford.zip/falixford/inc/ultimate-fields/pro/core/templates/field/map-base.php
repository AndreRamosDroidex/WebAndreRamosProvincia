<div class="uf-map">
	<div class="uf-map-ui">
		<div></div>
	</div>
	<div class="uf-map-controls">
		<div class="uf-map-field">
			<input type="text" placeholder="<?php esc_attr_e( 'Enter address to search...', 'ultimate-fields-pro' ) ?>" class="uf-map-input" />
		</div>
	</div>
</div>