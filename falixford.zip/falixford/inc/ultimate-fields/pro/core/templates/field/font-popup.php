<div class="attachments-browser uf-fonts">
	<div class="media-sidebar uf-fonts-sidebar"></div>
	<div class="uf-fonts-pagination"></div>
	<div class="attachments uf-fonts-list"></div>
</div>