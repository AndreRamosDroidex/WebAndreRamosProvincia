<div class="uf-repeater-placeholder uf-layout-placeholder"><?php _e( 'Drag an item here', 'ultimate-fields-pro' ) ?></div>
<span class="dashicons dashicons-menu uf-layout-handle"></span>
<div class="uf-layout-row-groups"></div>
