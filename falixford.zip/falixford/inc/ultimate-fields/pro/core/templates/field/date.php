<div class="uf-datepicker">
	<label class="uf-datepicker-icon" for="date-field-<%= id %>">
		<span class="dashicons dashicons-calendar-alt"></span>
	</label>

	<span class="uf-datepicker-input">
		<input type="text" value="" class="uf-datepicker-field" id="date-field-<%= id %>" />
	</span>
</div>