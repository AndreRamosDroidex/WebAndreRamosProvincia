<div class="uf-video">
	<div class="uf-video-preview-wrapper">
		<div class="uf-video-preview"></div>
	</div>
	<div class="uf-video-footer"></div>
</div>