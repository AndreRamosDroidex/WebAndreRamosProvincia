<span class="uf-icon-preview">
	<span class="<%= icon %> uf-icon-preview-icon"></span>
</span>