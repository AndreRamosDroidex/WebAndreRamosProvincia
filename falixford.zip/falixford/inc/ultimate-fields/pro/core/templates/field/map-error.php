<div class="uf-map-error">
	<p>
		<span class="dashicons dashicons-admin-site"></span>
		<?php _e( 'The Google Maps script could not be loaded. Please check if you have network connection and contact the site\'s administrator if you do.', 'ultimate-fields-pro' ) ?>
	</p>
</div>