<div class="uf-layout-content"></div>
<div class="uf-repeater-prototypes uf-layout-row uf-layout-draggables"></div>