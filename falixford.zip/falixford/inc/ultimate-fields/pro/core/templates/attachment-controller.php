<div class="uf-media-validation-message">
	<h4><?php _e( 'Your data contains errors', 'ultimate-fields-pro' ) ?></h4>
	<p><?php _e( 'Your data will not be saved unless you fix them!', 'ultimate-fields-pro' ) ?></p>
</div>