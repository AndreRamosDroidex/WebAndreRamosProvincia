<% if( description ){ %>
<header class="uf-shortcode-editor-header">
	<%= description %>
</header>
<% } %>

<div class="uf-fields uf-fields-label-200 uf-boxed-fields uf-shortcode-fields"></div>
