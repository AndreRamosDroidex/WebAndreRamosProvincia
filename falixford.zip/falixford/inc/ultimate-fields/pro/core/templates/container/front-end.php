<div class="uf-form-fields"></div>

<input type="hidden" name="<%= form %>_<%= id %>" value="" class="uf-container-data" />
