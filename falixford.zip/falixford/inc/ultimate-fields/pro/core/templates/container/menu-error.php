<div class="error uf-error">
	<p><strong><%= title %></strong></p>
</div>