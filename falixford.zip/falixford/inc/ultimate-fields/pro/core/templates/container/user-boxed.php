<div class="postbox uf-user-box">
	<h2 class="hndle"><span><?php echo $title ?></span></h2>

	<div class="inside">
		<?php echo $tag ?>
	</div>
</div>