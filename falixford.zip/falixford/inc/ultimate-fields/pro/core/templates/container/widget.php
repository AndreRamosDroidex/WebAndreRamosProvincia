<% if( description && description.length ) { %>
<div class="uf-container-description">
	<%= description %>
</div>
<% } %>

<div class="uf-fields"></div>

<input type="hidden" name="<%= inputName %>" value="" class="uf-container-data" />