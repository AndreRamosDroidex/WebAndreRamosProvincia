<% if( description && description.length ) { %>
<div class="uf-container-description">
	<%= description %>
</div>
<% } %>

<div class="uf-fields uf-boxed-fields">
</div>

<input type="hidden" name="uf_comment_meta_<%= id %>" value="" class="uf-container-data" />
