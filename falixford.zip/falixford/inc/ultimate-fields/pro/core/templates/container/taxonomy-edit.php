<% if( description && description.length ) { %>
<div class="uf-container-description">
	<%= description %>
</div>
<% } %>

<div class="uf-fields  uf-fields-label-200"></div>
<input type="hidden" name="uf_term_meta_<%= id %>" value="" class="uf-container-data" />