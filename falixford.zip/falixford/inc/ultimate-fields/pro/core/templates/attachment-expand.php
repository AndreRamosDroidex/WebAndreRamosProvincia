<span class="dashicons dashicons-arrow-left"></span>
<strong><%= text %></strong>
