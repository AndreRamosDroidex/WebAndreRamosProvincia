<div class="uf-media-warning">
    <p><?php _e( 'Some fields require additional space.<br />To see them, please expand the sidebar.', 'ultimate-fields-pro' ) ?></p>
    <p>
        <button type="button" class="button-secondary uf-button uf-attachment-expand">
            <span class="dashicons dashicons-editor-expand uf-button-icon"></span>
            <span class="uf-button-text"><?php _e( 'Expand sidebar', 'ultimate-fields-pro' ) ?></span>
        </button>
    </p>
</div>
