<?php
/**
 * Plugin name: Ultimate Fields: Pro (core)
 * Version: 3.0
 */
require_once __DIR__ . '/classes/Core.php';

Ultimate_Fields\Pro\Core::instance( __FILE__, true );
