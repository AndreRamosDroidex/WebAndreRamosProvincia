<p><span class="dashicons dashicons-no"></span> <?php echo $heading ?></p>
<div class="uf-tip">
	<span class="dashicons dashicons-warning uf-tip-icon"></span>
	<?php echo wpautop( $text ) ?>
</div>

<a href="https://www.google.com" target="_blank" class="button-secondary uf-button">
	<span class="dashicons dashicons-admin-site uf-button-icon"></span>
	<?php _e( 'Learn more', 'ultimate-fields' ) ?>
</a>
