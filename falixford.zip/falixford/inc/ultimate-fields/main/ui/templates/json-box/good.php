<p><span class="dashicons dashicons-yes"></span> <?php echo $heading ?></p>
<div class="uf-tip">
	<span class="dashicons dashicons-info uf-tip-icon"></span>
	<?php echo wpautop( $text ) ?>
</div>
