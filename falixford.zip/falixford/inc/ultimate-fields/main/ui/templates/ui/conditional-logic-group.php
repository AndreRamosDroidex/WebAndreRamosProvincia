<div class="uf-logic-group-body">
	<div class="uf-logic-group-rules">
		<span class="uf-logic-group-and"><strong><?php _e( 'and', '' ) ?></strong></span>
		
	</div>

	<button type="button" class="button-primary uf-button uf-logic-group-add-rule">
		<span class="dashicons dashicons-plus uf-button-icon"></span>
		<?php _e( 'Add rule', 'ultimate-fields' ) ?>
	</button>
</div>

<div class="uf-logic-group-footer">
	<button type="button" class="button-secondary uf-button uf-logic-group-remove">
		<span class="dashicons dashicons-trash uf-button-icon"></span>
		<?php _e( 'Delete group', 'ultimate-fields' ) ?>
	</button>	
</div>