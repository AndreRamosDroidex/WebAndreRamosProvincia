<div class="uf-logic-rule-element uf-logic-rule-field"></div>	
<div class="uf-logic-rule-element uf-logic-rule-comparator"></div>	
<div class="uf-logic-rule-element uf-logic-rule-value"></div>	

<a href="#" class="button-secondary uf-button uf-button-no-text uf-logic-rule-remove"><span class="dashicons dashicons-trash"></span></a>