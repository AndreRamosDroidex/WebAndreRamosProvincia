<?php
namespace Ultimate_Fields\UI\Field;

use Ultimate_Fields\Field;
use Ultimate_Fields\Template;

/**
 * Handles the field for selecting other fields.
 *
 * @since 3.0
 */
class Field_Selector extends Field {}
