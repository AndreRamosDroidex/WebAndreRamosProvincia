<?php
/**
 * Plugin name: Ultimate Fields: UI
 * Version: 3.0
 */
require_once __DIR__ . '/classes/UI.php';
Ultimate_Fields\UI\UI::instance( __FILE__, true );
