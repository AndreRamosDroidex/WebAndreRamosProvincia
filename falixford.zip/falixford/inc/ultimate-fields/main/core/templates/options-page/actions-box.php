<div class="uf-actions-box">
	<button type="submit" class="button-primary uf-button options-page-save">
		<span class="dashicons dashicons-category uf-button-icon"></span>
		<?php _e( 'Save', 'ultimate-fields' ) ?>
	</button>

	<div class="spinner"></div>
</div>
