<p>
	<span class="dashicons dashicons-warning"></span> <?php printf( __( 'The field name &quot;%s&quot; is already taken by another field, shown on this page.', 'ultimate-fields' ), $name ) ?>
</p>
