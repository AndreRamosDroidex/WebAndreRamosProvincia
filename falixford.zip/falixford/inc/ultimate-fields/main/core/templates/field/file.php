<div class="uf-file">
	<span class="uf-file-preview"></span>
	<span class="uf-file-buttons"></span>
</div>