<div class="uf-table-heading">
	<h4><%= label %></h4>

	<% if( ( 'undefined' != typeof description ) && description ){ %>
	<div class="uf-field-description"><%= description %></div>
	<% } %>
</div>
