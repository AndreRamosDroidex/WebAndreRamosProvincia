<p class="uf-chooser-no-data">
	<span class="dashicons dashicons-no"></span>
	No results found.
</p>