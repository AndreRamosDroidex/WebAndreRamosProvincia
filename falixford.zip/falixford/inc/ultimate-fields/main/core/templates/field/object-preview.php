<div class="uf-object">
	<div class="uf-object-preview uf-object-preview-<%= item.type %>">
		<%= item.html %>
	</div>

	<div class="uf-object-buttons"></div>
</div>