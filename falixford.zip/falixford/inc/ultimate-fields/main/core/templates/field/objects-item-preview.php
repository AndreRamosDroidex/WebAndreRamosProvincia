<div class="uf-objects-item-handle">
	<span class="dashicons dashicons-menu"></div>
</div>

<div class="uf-object-preview uf-objects-item-wrapper">
</div>

<button class="uf-objects-item-remove">
	<span class="dashicons dashicons-no"></div>
</button>