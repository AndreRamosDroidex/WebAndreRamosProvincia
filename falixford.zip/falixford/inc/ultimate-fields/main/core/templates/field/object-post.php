<div class="uf-object-preview-body">
	<h4>
		<a href="<?php echo $link ?>" target="_blank">
			<span class="dashicons dashicons-edit"></span>
			<?php echo esc_html( $title ) ?>
		</a>
	</h4>
	<p><?php echo $description ?></p>
</div>