<div class="uf-object-preview">
	<%= html %>
</div>