<div class="uf-group uf-group-prototype" data-type="<%= id %>">
	<div class="uf-group-header">
		<div class="uf-group-number">
			<strong class="dashicons dashicons-plus"></strong>
		</div>

		<h3 class="uf-group-title"><%= title %></h3>
	</div>
</div>

<%= description %>