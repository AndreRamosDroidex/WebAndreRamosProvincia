<h4>
	<% if( icon ){ %>
		<span class="<%= icon %>"></span>
	<% } %>
	<%= label %>
</h4>

<%= description %>