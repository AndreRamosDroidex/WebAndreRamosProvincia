<div class="uf-overlay-alert">
	<div class="background"></div>

	<div class="box">
		<h2><%= title %></h2>
		<div class="uf-overlay-alert-body"></div>
		<div class="uf-overlay-alert-footer"></div>		
	</div>
</div>