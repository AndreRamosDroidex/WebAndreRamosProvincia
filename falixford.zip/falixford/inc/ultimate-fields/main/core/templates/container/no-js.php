<div class="hide-if-js">
	<p class="uf-no-js">
		<span class="dashicons dashicons-hidden"></span>
		<?php echo esc_html( __( 'You need to enable JavaScript in your browser in order to edit those fields.', 'ultimate-fields' ) ) ?>
	</p>
</div>
