<div class="uf-inline-tab <% if( ! visible ) { %>uf-inline-tab-disabled<% } %>">
    <h3 class="uf-inline-tab-title"><%= label %></h3>

    <button type="button" class="button-secondary uf-button uf-button-no-text uf-inline-tab-toggle">
        <span class="uf-button-icon dashicons dashicons-arrow-down"></span>
    </button>
</div>
