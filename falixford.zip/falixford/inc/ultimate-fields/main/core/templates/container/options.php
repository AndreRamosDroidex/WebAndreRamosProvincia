<% if( description && description.length ) { %>
<div class="uf-container-description">
	<%= description %>
</div>
<% } %>

<div class="uf-fields uf-boxed-fields"></div>

<input type="hidden" name="uf_options_<%= id %>" value="" class="uf-container-data" />