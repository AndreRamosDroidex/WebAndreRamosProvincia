<div class="uf-overlay-background"></div>
<div class="uf-overlay-box">
	<header class="uf-overlay-header">
		<h2 class="uf-overlay-title"></h2>
		<button type="button" class="uf-overlay-close">
			<span class="dashicons dashicons-no-alt"></span>
			<span class="screen-reader-text"><?php _e( 'Close overlay', 'uf' ) ?></span>
		</button>
	</header>

	<div class="uf-overlay-body"></div>

	<footer class="uf-overlay-footer"></footer>
</div>