<?php
/**
 * Plugin name: Ultimate Fields: Core
 * Version: 3.0
 */
require_once __DIR__ . '/classes/Core.php';

Ultimate_Fields\Core::instance( __FILE__, true );